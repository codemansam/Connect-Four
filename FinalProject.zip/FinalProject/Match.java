/**
 * 
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Match
{
    private int column = 0;
    private int count = 0;
    
    public int getColumn() {
        return column;
    }
    
    public void setColumn(int i) {
        this.column = i;
    }
    
    public int getCount() {
        return count;
    }
    
    public void setCount(int i) {
        this.count = i;
    }
}
